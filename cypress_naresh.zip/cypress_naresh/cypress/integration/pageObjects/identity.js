class identity {
    ideday() {
        return cy.get('[data-testid=expiryDate] > :nth-child(1) > .EspFormTextField__Wrapper-sc-1gtaw3o-0 > [data-test=day]')
    }

    ideyear() {
        return cy.get('[data-testid=expiryDate] > .EspDatePicker__EspGridItem40-xvx28u-2 > .EspFormTextField__Wrapper-sc-1gtaw3o-0 > [data-test=year]') 
    }

    idemonth() {
        return cy.get('[data-testid=expiryDate] > :nth-child(2) > .EspFormTextField__Wrapper-sc-1gtaw3o-0 > [data-test=month]')
    }
}
export default identity