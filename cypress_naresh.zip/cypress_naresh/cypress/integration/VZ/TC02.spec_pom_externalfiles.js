import Identity from '../pageObjects/identity'

describe("visit persoonlijke-gegevens/gegevens and provide user data", function() {
    const identity = new Identity()
    
    //launch Vodafon.nl site with deeplink url and verify
    it('launch Vodafon.nl site with deeplink url and verify',function() {
        cy.visit('https://www.vodafone.nl/bestellen/direct?converged=false&products[0][subscriptionSku]=4110646')
        //Handling cookies
        cy.get('.lgi_btn_3').then(($btn) => {
            if ($btn.find.length > 0) {
                cy.get('.lgi_btn_3').click({ force: true })
            }
    })
})

    //Verify bestellen screen and proceed to customer details screen
    it('bestellen',function(){
        cy.url().should('include', 'bestellen');
        cy.contains('Start M 1 jaar',{timeout:50000}).should('be.visible')
        cy.title().should('eq','Winkelwagen - Vodafone.nl')
        cy.contains('Volgende stap').click({ force: true })
    })

    //Enter customer details and click next
    it('customer details section', function(){
       cy.contains('Je persoonsgegevens',{timeout:50000}).should('be.visible')
       cy.contains('Privé').click({ force: true })
       cy.contains('Meneer').click({ force: true })
       cy.get('#gegevens-initials').type('NKR')
       cy.get('#gegevens-lastName').type('test')
       cy.get('[data-test=day]').first().type(Math.floor(Math.random() * 30) + 1)
       cy.get('[data-test=month]').first().type(Math.floor(Math.random() * 10) + 1)
       cy.get('[data-test=year]').first().type(Math.floor(Math.random() * 60) + 1930)
       cy.contains('Volgende').should('be.visible').click({ force: true })
       cy.wait(5000)
       cy.url().should('include', 'contact');
       cy.get('#contact-phone1').type(Math.floor('3163362045' + Math.random() * 10))
       cy.get('#contact-email').type('testing' + Math.floor(Math.random() * 99) + 1 +'@zoho.com')
       cy.get('[data-testid=next-form-step-contact]').contains('Volgende').click({ force: true })
    })

    //Enter customer address details and click next
    it('address section',function() {
       cy.wait(5000)
       cy.url().should('include', 'adres');
       cy.get('[data-testid=postcode]').type('2134RE')
       cy.get('[data-testid=houseNumber]').type(Math.floor(Math.random() * 20) * 2)
       cy.wait(5000)
       cy.get('[data-testid=next-form-step-address]',{timeout:10000}).contains('Volgende').click({ force: true })
    })

    //Enter customer identificatie details and click next
    it('identificatie section',function(){
       cy.wait(5000)
       cy.url().should('include', 'identificatie');
       cy.get('#type').select('Nederlandse ID kaart')
       var idnum = 'NL786d' + Math.floor(Math.random() * 70) + 5
       cy.get('#legitimatie-documentNumber').type(idnum)
       cy.writeFile('samplewriteFile.txt',idnum)
       identity.ideday().type(Math.floor(Math.random() * 30) + 1)
       identity.idemonth().type(Math.floor(Math.random() * 10) + 1)
       identity.ideyear().type(Math.floor(Math.random() * 10) + 2021)
       cy.wait(5000)
       cy.get('[data-testid=identification]',{timeout:10000}).contains('Volgende').click({ force: true })
    })

    //Enter customer iban details and click next
    it('bankdetails',function() {
        cy.get('[data-testid=ibanBankDigits]').type(70)
        cy.get('[data-testid=ibanBankCode]').type('ABNA')
        cy.readFile('sampleFile.txt').then(obj => {
            cy.get('[data-testid=ibanAccountNumber]').type(obj)
        })
    })
})