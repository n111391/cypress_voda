// /// <reference types="cypress" />

describe("visit vodafone.nl and veridy", function() {
    
    it('launch and verify',function() {
        cy.visit('www.vodafone.nl')
        cy.wait(2500)
    //Handling cookies
        cy.get('.lgi_btn_3').then(($btn) => {
            if ($btn.find.length > 0) {
                cy.get('.lgi_btn_3').click({ force: true })
            }
        })
    })

    
    it('handling cookies',function() {
    //selecting simonly option
        cy.wait(2000)
        cy.get('.button').contains('Sim Only').should('be.visible').click({ force: true })
        
        cy.title().should('eq','Vodafone')

     cy.get('[data-testid=vfz-button-converged-status-prompt--no]').then(($bt) => {
            if ($bt.is(':visible')) {
                cy.get('[data-testid=vfz-button-converged-status-prompt--no]').click({ force: true })
            }
       })
    })

    //selecting subscriptions and verification
    it('Je Sim Only abonnement',function() {
       cy.get('.vfz-mobile-pdp__page-title').contains('Je Sim Only abonnement').should('be.visible')

       cy.get('[data-testid="vfz-subscription-listing--Start M"]').click({ force: true })
       
       cy.get('[data-testid="vfz-duration--1 jaar"]').click({ force: true })

       cy.contains('Start M 1 jaar').should('be.visible')
       
        })
})