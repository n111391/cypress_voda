import {Given, When, Then , And} from "cypress-cucumber-preprocessor/steps"

Given('User is on the home page', () => {
  cy.visit('www.vodafone.nl')
    //Handling cookies
    cy.get('.lgi_btn_3').then(($btn) => {
      if ($btn.find.length > 0) {
          cy.get('.lgi_btn_3').click({ force: true })
      }
    })
  });

  When('I select SIMOnly option', () => {
    cy.get('.button').contains('Sim Only').click({ force: true })
    cy.get('[data-testid=vfz-button-converged-status-prompt--no]').then(($bt) => {
      if ($bt.is(':visible')) {
          cy.get('[data-testid=vfz-button-converged-status-prompt--no]').click({ force: true })
      }
  })
  });

  
  Then('Page title should be {string}', (content) => {
    cy.title().should('eq',content)
  });

  Then('Title {string} should be shown', (content) => {
    cy.get('.vfz-mobile-pdp__page-title').contains(content).should('be.visible')
  });
  
  When('I selects Start M and 1 year option', () => {
    cy.get('[data-testid="vfz-subscription-listing--Start M"]').click({ force: true })
    cy.get('[data-testid="vfz-duration--1 jaar"]').click({ force: true })
  });
  
  Then('{string} should be shown under product selection', (content) => {
    cy.contains(content).should('be.visible')
  });